# PI.ps1
$PI = 3.14
Write-Host "The value of `$PI is $PI et aussi la variable etewndu de la consiole $testEtendu "
